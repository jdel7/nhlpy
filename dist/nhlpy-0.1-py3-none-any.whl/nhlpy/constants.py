"""
Constants used throughout the project
"""

BASE_URL = 'https://statsapi.web.nhl.com/api/v1'
